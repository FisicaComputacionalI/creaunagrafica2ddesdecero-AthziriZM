import numpy as np
import pylab as pl
x=[1,2,3,4]
y=[7.25,9.6,8,7.66]
pl.plot(x, y)
pl.savefig('promedio.png')